--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-2.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-2.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_audio; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_audio (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    mp3 character varying(100),
    user_id integer NOT NULL,
    duration interval,
    m4a character varying(100),
    subtitle character varying(512),
    title character varying(255),
    oga character varying(100),
    opus character varying(100)
);


ALTER TABLE public.cast_audio OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_audio_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_audio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_audio_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_audio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_audio_id_seq OWNED BY public.cast_audio.id;


--
-- Name: cast_blog; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_blog (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(500) NOT NULL,
    slug character varying(50) NOT NULL,
    user_id integer NOT NULL,
    uuid uuid NOT NULL,
    email character varying(254),
    itunes_artwork_id integer,
    keywords character varying(255) NOT NULL,
    explicit smallint NOT NULL,
    itunes_categories character varying(512) NOT NULL,
    CONSTRAINT cast_blog_explicit_check CHECK ((explicit >= 0))
);


ALTER TABLE public.cast_blog OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_blog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_blog_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_blog_id_seq OWNED BY public.cast_blog.id;


--
-- Name: cast_file; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_file (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    original character varying(100) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.cast_file OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_file_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_file_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_file_id_seq OWNED BY public.cast_file.id;


--
-- Name: cast_gallery; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_gallery (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.cast_gallery OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_gallery_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_gallery_id_seq OWNED BY public.cast_gallery.id;


--
-- Name: cast_gallery_images; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_gallery_images (
    id integer NOT NULL,
    gallery_id integer NOT NULL,
    image_id integer NOT NULL
);


ALTER TABLE public.cast_gallery_images OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_gallery_images_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_gallery_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_gallery_images_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_gallery_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_gallery_images_id_seq OWNED BY public.cast_gallery_images.id;


--
-- Name: cast_image; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_image (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    original character varying(100) NOT NULL,
    original_height integer,
    original_width integer,
    user_id integer NOT NULL,
    CONSTRAINT cast_image_original_height_check CHECK ((original_height >= 0)),
    CONSTRAINT cast_image_original_width_check CHECK ((original_width >= 0))
);


ALTER TABLE public.cast_image OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_image_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_image_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_image_id_seq OWNED BY public.cast_image.id;


--
-- Name: cast_itunesartwork; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_itunesartwork (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    original character varying(100) NOT NULL,
    original_height integer,
    original_width integer,
    CONSTRAINT cast_itunesartwork_original_height_check CHECK ((original_height >= 0)),
    CONSTRAINT cast_itunesartwork_original_width_check CHECK ((original_width >= 0))
);


ALTER TABLE public.cast_itunesartwork OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_itunesartwork_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_itunesartwork_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_itunesartwork_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_itunesartwork_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_itunesartwork_id_seq OWNED BY public.cast_itunesartwork.id;


--
-- Name: cast_post; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_post (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    pub_date timestamp with time zone,
    visible_date timestamp with time zone NOT NULL,
    content text NOT NULL,
    slug character varying(50) NOT NULL,
    author_id integer NOT NULL,
    blog_id integer NOT NULL,
    podcast_audio_id integer,
    uuid uuid NOT NULL,
    keywords character varying(255) NOT NULL,
    explicit smallint NOT NULL,
    block boolean NOT NULL,
    CONSTRAINT cast_post_explicit_check CHECK ((explicit >= 0))
);


ALTER TABLE public.cast_post OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_audios; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_post_audios (
    id integer NOT NULL,
    post_id integer NOT NULL,
    audio_id integer NOT NULL
);


ALTER TABLE public.cast_post_audios OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_audios_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_post_audios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_post_audios_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_audios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_post_audios_id_seq OWNED BY public.cast_post_audios.id;


--
-- Name: cast_post_galleries; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_post_galleries (
    id integer NOT NULL,
    post_id integer NOT NULL,
    gallery_id integer NOT NULL
);


ALTER TABLE public.cast_post_galleries OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_galleries_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_post_galleries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_post_galleries_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_galleries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_post_galleries_id_seq OWNED BY public.cast_post_galleries.id;


--
-- Name: cast_post_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_post_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_post_id_seq OWNED BY public.cast_post.id;


--
-- Name: cast_post_images; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_post_images (
    id integer NOT NULL,
    post_id integer NOT NULL,
    image_id integer NOT NULL
);


ALTER TABLE public.cast_post_images OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_images_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_post_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_post_images_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_post_images_id_seq OWNED BY public.cast_post_images.id;


--
-- Name: cast_post_videos; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_post_videos (
    id integer NOT NULL,
    post_id integer NOT NULL,
    video_id integer NOT NULL
);


ALTER TABLE public.cast_post_videos OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_post_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_post_videos_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_post_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_post_videos_id_seq OWNED BY public.cast_post_videos.id;


--
-- Name: cast_video; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.cast_video (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    original character varying(100) NOT NULL,
    poster character varying(100),
    poster_seconds double precision NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.cast_video OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_video_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.cast_video_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cast_video_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: cast_video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.cast_video_id_seq OWNED BY public.cast_video.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: cast_audio id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_audio ALTER COLUMN id SET DEFAULT nextval('public.cast_audio_id_seq'::regclass);


--
-- Name: cast_blog id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_blog ALTER COLUMN id SET DEFAULT nextval('public.cast_blog_id_seq'::regclass);


--
-- Name: cast_file id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_file ALTER COLUMN id SET DEFAULT nextval('public.cast_file_id_seq'::regclass);


--
-- Name: cast_gallery id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery ALTER COLUMN id SET DEFAULT nextval('public.cast_gallery_id_seq'::regclass);


--
-- Name: cast_gallery_images id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery_images ALTER COLUMN id SET DEFAULT nextval('public.cast_gallery_images_id_seq'::regclass);


--
-- Name: cast_image id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_image ALTER COLUMN id SET DEFAULT nextval('public.cast_image_id_seq'::regclass);


--
-- Name: cast_itunesartwork id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_itunesartwork ALTER COLUMN id SET DEFAULT nextval('public.cast_itunesartwork_id_seq'::regclass);


--
-- Name: cast_post id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post ALTER COLUMN id SET DEFAULT nextval('public.cast_post_id_seq'::regclass);


--
-- Name: cast_post_audios id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_audios ALTER COLUMN id SET DEFAULT nextval('public.cast_post_audios_id_seq'::regclass);


--
-- Name: cast_post_galleries id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_galleries ALTER COLUMN id SET DEFAULT nextval('public.cast_post_galleries_id_seq'::regclass);


--
-- Name: cast_post_images id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_images ALTER COLUMN id SET DEFAULT nextval('public.cast_post_images_id_seq'::regclass);


--
-- Name: cast_post_videos id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_videos ALTER COLUMN id SET DEFAULT nextval('public.cast_post_videos_id_seq'::regclass);


--
-- Name: cast_video id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_video ALTER COLUMN id SET DEFAULT nextval('public.cast_video_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
5	jochen-pythonpodcast@wersdoerfer.de	t	t	4
6	podcast@soila.de	t	t	5
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add user	12	add_user
46	Can change user	12	change_user
47	Can delete user	12	delete_user
48	Can view user	12	view_user
49	Can add Token	13	add_token
50	Can change Token	13	change_token
51	Can delete Token	13	delete_token
52	Can view Token	13	view_token
53	Can add blog	14	add_blog
54	Can change blog	14	change_blog
55	Can delete blog	14	delete_blog
56	Can view blog	14	view_blog
57	Can add file	15	add_file
58	Can change file	15	change_file
59	Can delete file	15	delete_file
60	Can view file	15	view_file
61	Can add gallery	16	add_gallery
62	Can change gallery	16	change_gallery
63	Can delete gallery	16	delete_gallery
64	Can view gallery	16	view_gallery
65	Can add image	17	add_image
66	Can change image	17	change_image
67	Can delete image	17	delete_image
68	Can view image	17	view_image
69	Can add post	18	add_post
70	Can change post	18	change_post
71	Can delete post	18	delete_post
72	Can view post	18	view_post
73	Can add video	19	add_video
74	Can change video	19	change_video
75	Can delete video	19	delete_video
76	Can view video	19	view_video
77	Can add audio	20	add_audio
78	Can change audio	20	change_audio
79	Can delete audio	20	delete_audio
80	Can view audio	20	view_audio
81	Can add itunes art work	21	add_itunesartwork
82	Can change itunes art work	21	change_itunesartwork
83	Can delete itunes art work	21	delete_itunesartwork
84	Can view itunes art work	21	view_itunesartwork
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: cast_audio; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_audio (id, created, modified, mp3, user_id, duration, m4a, subtitle, title, oga, opus) FROM stdin;
5	2018-11-21 10:21:21.63893+00	2018-11-21 10:43:48.075534+00	cast_audio/pp_01.mp3	4	01:43:27.62	cast_audio/pp_01.m4a	Dominik und Jochen unterhalten sich über den Podcast und Python	Vorstellung und Python-Einführung - Episode 1	cast_audio/pp_01.ogg	cast_audio/pp_01.opus
6	2018-11-28 10:18:49.960431+00	2018-11-28 10:24:03.298493+00	cast_audio/pp-02.mp3	4	01:46:32.71	cast_audio/pp-02.m4a	Johannes, Dominik und Jochen unterhalten sich über das Web-Framework Django	Django - Episode 2	cast_audio/pp-02.ogg	cast_audio/pp-02.opus
7	2018-12-18 09:20:54.08528+00	2018-12-18 09:22:46.35915+00	cast_audio/pp_03.mp3	4	01:41:51.79	cast_audio/pp_03.m4a	Dominik und Jochen reden über alles ausser Python ;)	Weihnachtsfolge - Episode 3	cast_audio/pp_03.ogg	cast_audio/pp_03.opus
8	2019-02-20 11:19:06.299035+00	2019-02-21 17:43:03.339892+00	cast_audio/pp_04.mp3	4	01:37:07.6	cast_audio/pp_04.m4a	Wir unterhalten uns mit Niklas und Dodo	Python für Einsteiger - Episode 4	cast_audio/pp_04.ogg	cast_audio/pp_04.opus
9	2019-02-25 11:27:13.90461+00	2019-02-25 11:27:25.308555+00	cast_audio/pp05.mp3	4	03:10:46.39	cast_audio/pp05.m4a	Dominik und Jochen unterhalten sich über Datenbanken	Datenbanken - Episode 5	cast_audio/pp05.ogg	cast_audio/pp05.opus
10	2019-02-25 11:41:04.484532+00	2019-02-25 11:41:08.395298+00	cast_audio/pp05.mp3	4	03:10:46.39	cast_audio/pp05.m4a	Dominik und Jochen unterhalten sich über Datenbanken	Datenbanken - Episode 5		
\.


--
-- Data for Name: cast_blog; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_blog (id, created, modified, title, description, slug, user_id, uuid, email, itunes_artwork_id, keywords, explicit, itunes_categories) FROM stdin;
1	2018-11-21 10:45:39.461568+00	2019-02-23 10:21:38.64406+00	Python Podcast	Ein deutschsprachiger Podcast rund um die Programmiersprache Python	show	4	7691b392-1765-4327-a0fa-7c69640a4d92	hallo@python-podcast.de	1	python,programming,data science,django,machine learning	2	{"Technology": ["Software How-To", "Tech News"]}
\.


--
-- Data for Name: cast_file; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_file (id, created, modified, original, user_id) FROM stdin;
\.


--
-- Data for Name: cast_gallery; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_gallery (id, created, modified, user_id) FROM stdin;
\.


--
-- Data for Name: cast_gallery_images; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_gallery_images (id, gallery_id, image_id) FROM stdin;
\.


--
-- Data for Name: cast_image; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_image (id, created, modified, original, original_height, original_width, user_id) FROM stdin;
\.


--
-- Data for Name: cast_itunesartwork; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_itunesartwork (id, created, modified, original, original_height, original_width) FROM stdin;
1	2018-11-21 09:18:45.339582+00	2018-11-30 14:40:34.546525+00	cast_images/itunes_artwork/pp_itunes_artwork_3k.png	3000	3000
\.


--
-- Data for Name: cast_post; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_post (id, created, modified, title, pub_date, visible_date, content, slug, author_id, blog_id, podcast_audio_id, uuid, keywords, explicit, block) FROM stdin;
2	2018-11-21 10:50:09.479969+00	2018-12-01 20:30:47.840031+00	PP01 - Die erste Sendung	2018-11-28 11:04:17+00	2018-12-01 00:00:00+00	<p>Es gibt einen neuen deutschsprachigen Python-Podcast. Zun&auml;chst hatten wir vor, einen anderen Namen zu verwenden, aber den fanden wir dann doch irgendwie doof. Und auf der Suche nach einer Domain fiel uns auf, dass python-podcast.de noch frei war. Gut, dann wird das eben nicht ein sondern der neue Python-Podcast :), dessen erste Folge wir&nbsp;vor Kurzem&nbsp;aufgenommen haben!</p>\r\n{% audio 5 %}\r\n\r\n<p>Wir - das sind Dominik und Jochen.&nbsp;In der ersten Sendung erz&auml;hlen wir ein wenig &uuml;ber uns und unseren Weg zu Python. Danach geben wir einen kurzen &Uuml;berblick &uuml;ber die Geschichte,&nbsp;Gegenwart und Zukunft von Python, um dann hemmungslos in alle m&ouml;glichen Richtungen abzuschweifen.</p>\r\n\r\n<h2>Shownotes</h2>\r\nUnsere E-Mail f&uuml;r Fragen, Anregungen &amp; Kommentare: <a href="mailto:hallo@python-podcast.de">hallo@python-podcast.de</a><br />\r\n<br />\r\n<a href="https://www.python.org/downloads/">Python-Download</a><br />\r\n<a href="https://docs.python.org/">Offizielle Dokumentation</a><br />\r\n<br />\r\nInterview mit Guido van Rossum &uuml;ber die Geschichte von Python in der<br />\r\n<a href="https://talkpython.fm/episodes/show/100/python-past-present-and-future-with-guido-vanrossum">Episode #100 von TalkPythonToMe</a> (englischsprachig)<br />\r\n&nbsp;\r\n<p>Empfohlene Tutorials:</p>\r\n\r\n<ul>\r\n\t<li><a href="https://learnpythonthehardway.org/">Learn Python the Hard Way</a>&nbsp;| Zed A. Shaw</li>\r\n\t<li><a href="https://automatetheboringstuff.com/">Automate the Boring Stuff with Python</a> | Al Sweigart</li>\r\n\t<li>Dan Bader ver&ouml;ffentlicht regelm&auml;&szlig;ig tolle Artikel &amp; Tutorials auf <a href="https://realpython.com/">RealPython.com</a><br />\r\n\t<br />\r\n\tEs gibt f&uuml;r Python unz&auml;hlige andere - auch kostenlose - Tutorials, einfach mal die Suchmaschine anschmei&szlig;en 8-)</li>\r\n</ul>	pp-01-initial-commit	5	1	5	e2907be0-8199-466c-bd12-cd1a6bb12f3c	python,introduction,programming languages,python lernen	2	f
3	2018-11-28 10:18:18.053145+00	2018-12-21 11:15:06.713754+00	PP02 - Django	2018-12-21 11:15:06.711692+00	2018-12-20 00:00:00+00	Willkommen zur zweiten Episode unseres Python-Podcasts. Diesmal dreht sich alles um das Thema Django.<br />\r\n<br />\r\n{% audio 6 %}<br />\r\n&nbsp;\r\n<h2>Shownotes</h2>\r\nUnsere E-Mail f&uuml;r Fragen, Anregungen &amp; Kommentare: <a href="mailto:hallo@python-podcast.de">hallo@python-podcast.de</a><br />\r\n<br />\r\n<a href="https://www.djangoproject.com/">Django Web-Framework</a><br />\r\nTutorial <a href="https://www.twoscoopspress.com/">Two Scoops of Django</a><br />\r\nModel View Controller (in Python) <a href="https://realpython.com/the-model-view-controller-mvc-paradigm-summarized-with-legos/">einfach erkl&auml;rt am Beispiel von Legosteinen</a><br />\r\n<a href="https://github.com/pydanny/cookiecutter-django">Cookiecutter</a> f&uuml;r Django<br />\r\n<a href="https://bitbucket.org/shezi/commandeer/">Commandeer</a>&nbsp;- command line interface f&uuml;r Pythonpogramme<br />\r\n<a href="https://github.com/matthewwithanm/django-imagekit">Django-Imagekit</a>&nbsp;- Bildgr&ouml;ssentransformationen etc. f&uuml;r Django	pp02-django	4	1	6	3761c305-6983-4eeb-ab72-e7f7a0bee46d		2	f
4	2018-12-18 09:24:31.059239+00	2018-12-24 12:38:15.521416+00	PP03 - Weihnachtsfolge	2018-12-24 12:38:15.51959+00	2018-12-24 00:00:00+00	In der dritten Episode unseres Python-Podcasts geht es ausnahmsweise gar nicht so viel um Python. Jochen erz&auml;hlt, was er im Web so macht und was f&uuml;r struggles ihm da aktuell so begegnen. Ziemlich chaotisch diese Folge. Weihnachtsstress pur :)<br />\r\n<br />\r\n{% audio 7 %}\r\n<h2>Shownotes</h2>\r\nUnsere E-Mail f&uuml;r Fragen, Anregungen &amp; Kommentare: <a href="mailto:hallo@python-podcast.de">hallo@python-podcast.de</a><br />\r\n<br />\r\nBrowser-Engines: <a href="https://svn.webkit.org/repository/webkit/">webkit</a>, <a href="https://chromium.googlesource.com/chromium/src/+/master/third_party/blink/">blink</a><br />\r\n<br />\r\nDo you believe:&nbsp;<a href="http://churchofgoogle.org/">Church of Google</a>&nbsp;?<br />\r\nFreie SSL-Zertifikate bei <a href="https://letsencrypt.org/">Let&#39;s Encrypt</a><br />\r\nGro&szlig;rechner der <a href="https://www.ibm.com/de-de/it-infrastructure/z">IBM-Z-Series</a><br />\r\n<br />\r\nPython mit <a href="https://github.com/graphql-python/graphene">graphql-graphene</a><br />\r\nChrome-Extension <a href="https://chrome.google.com/webstore/detail/apollo-client-developer-t/jdkknkkbebbapilgoeccciglkfbmbnfm">Apollo</a>, ein Debugging Tool f&uuml;r GraphQL<br />\r\nWes McKinney: <a href="http://wesmckinney.com/blog/apache-arrow-pandas-internals/">10 things I hate about pandas</a><br />\r\n<br />\r\nFalls wer die Rede von Heinz Nixdorf zur Cebit-Er&ouml;ffnung oder andere n&uuml;tzliche Dinge findet, bitte Bescheid geben.	pp03-weihnachten	4	1	7	e224dff1-32e8-4f87-8c73-ded96444c576		2	f
7	2019-02-25 09:38:53.140173+00	2019-02-25 14:09:50.995585+00	PP05 - Datenbanken	2019-02-25 13:37:00+00	2019-02-25 13:37:37+00	Wir haben uns diesmal zum Thema Datenbanken und Python zusammen gesetzt. Datenbanken sind ein weites Feld und daher ist diese Sendung auch ein bisschen l&auml;nger geworden.<br />\r\n<br />\r\n{% audio 9 %}\r\n<h2>Shownotes</h2>\r\nDatenbanken\r\n\r\n<ul>\r\n\t<li><a href="https://www.postgresql.org/">Postgres</a></li>\r\n\t<li><a href="https://www.mysql.com/">MySQL</a>&nbsp;<a href="https://mariadb.org/">MariaDB</a></li>\r\n\t<li><a href="https://www.mongodb.com/">MongoDB</a></li>\r\n\t<li><a href="http://couchdb.apache.org/">CouchDB</a></li>\r\n\t<li><a href="https://dgraph.io/">Dgraph</a></li>\r\n\t<li><a href="https://neo4j.com/">Neo4j</a></li>\r\n\t<li><a href="https://redis.io/">Redis</a></li>\r\n\t<li><a href="https://www.influxdata.com/">InfluxDB</a></li>\r\n\t<li><a href="https://www.timescale.com/">TimescaleDB</a></li>\r\n\t<li><a href="http://lucene.apache.org/">Lucene</a>&nbsp;<a href="http://lucene.apache.org/solr/">Solr</a>&nbsp;<a href="https://www.elastic.co/">Elastichsearch</a></li>\r\n</ul>\r\n\r\n<h3>Python ORM</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://docs.djangoproject.com/en/2.1/topics/db/">Django</a></li>\r\n\t<li><a href="https://www.sqlalchemy.org/">SQLAlchemy</a></li>\r\n\t<li><a href="https://ponyorm.org/">Pony</a></li>\r\n\t<li><a href="http://docs.peewee-orm.com/en/latest/">peewee</a></li>\r\n</ul>\r\n\r\n<h3>&quot;Big Data&quot;</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://docs.ibis-project.org/">Ibis</a></li>\r\n\t<li><a href="https://arrow.apache.org/">Arrow</a></li>\r\n\t<li><a href="https://spark.apache.org/docs/latest/api/python/index.html">pyspark</a></li>\r\n</ul>\r\n\r\n<h3>Papers</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://www.seas.upenn.edu/~zives/03f/cis550/codd.pdf">A Relational Model of Data for Large Shared Data Banks </a></li>\r\n\t<li><a href="http://db.csail.mit.edu/projects/cstore/vldb.pdf">C-Store: A Column-oriented DBMS</a></li>\r\n</ul>\r\n\r\n<h3>Picks</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://www.sqlite.org/index.html">Sqlite</a></li>\r\n\t<li><a href="https://github.com/simonw/datasette/blob/master/README.md">Datasette</a></li>\r\n\t<li><a href="https://magic.io/blog/asyncpg-1m-rows-from-postgres-to-python/">Async binary driver for postgres</a></li>\r\n\t<li><a href="https://docs.python.org/3/library/pickle.html">Pickle</a></li>\r\n</ul>\r\n\r\n<h3>Quellen</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://www.dataengineeringpodcast.com/data-serialization-with-doug-cutting-and-julien-le-dem-episode-8/">Data serialization formats</a></li>\r\n\t<li><a href="https://www.dataengineeringpodcast.com/postgresql-with-jonathan-katz-episode-42/">Taking a tour of postgres</a></li>\r\n\t<li><a href="https://www.youtube.com/watch?feature=share&amp;v=43DZEy_J694&amp;app=desktop">Everything is miscellaneous</a></li>\r\n\t<li><a href="https://tomaugspurger.github.io/method-chaining">Method Chaining</a></li>\r\n\t<li><a href="https://simonwillison.net/2017/Oct/5/django-postgresql-faceted-search/">Implementing faceted search with Django and PostgreSQL</a></li>\r\n\t<li><a href="http://philip.greenspun.com/wtr/data-warehousing.html">Data Warehousing for Cavemen</a></li>\r\n</ul>	datenbanken	4	1	9	2f565a04-b0a1-4e08-892f-536a9c0b8e63	python,datenbanken,oltp,olap,nosql,sql	2	f
5	2019-02-20 06:11:26.871748+00	2019-02-21 17:42:26.233945+00	PP04 - Python für Einsteiger	2019-02-20 22:48:20+00	2019-02-20 00:00:00+00	Heute haben wir uns mit&nbsp;<a href="https://twitter.com/YtvwlD">Niklas</a>&nbsp;und&nbsp;<a href="https://twitter.com/_d_0_d_0">Dodo</a>&nbsp;getroffen, die im&nbsp;<a href="https://chaosdorf.de/">Chaosdorf</a>&nbsp;die Python-Einsteigerveranstaltung betreuen, und &uuml;ber ihren Kurs sowie ganz allgemein &uuml;ber Einstiege in Python gesprochen.<br />\r\n<br />\r\n{% audio 8 %}\r\n<h2>Shownotes</h2>\r\nUnsere E-Mail f&uuml;r Fragen, Anregungen &amp; Kommentare: <a href="mailto:hallo@python-podcast.de">hallo@python-podcast.de</a>\r\n\r\n<h3>Allgemein</h3>\r\n\r\n<ul>\r\n\t<li>Python Anf&auml;ngerkurs im <a href="https://chaosdorf.de/">Chaosdorf</a>:&nbsp;<a href="https://github.com/pythonfoo/pythonfooLite/wiki">PythonfooLite</a>&nbsp;<a href="https://github.com/pythonfoo/pythonfooLite">github repo</a></li>\r\n\t<li><a href="https://web.telegram.org/#/im?p=@pyddf">Pyddf telegram channel</a></li>\r\n\t<li><a href="https://www.python.org/dev/peps/pep-0505/">PEP 505 -- None-aware operators</a></li>\r\n\t<li><a href="https://github.com/s0md3v/hue">huepy</a></li>\r\n\t<li><a href="https://en.wikipedia.org/wiki/Felicific_calculus">Benthams algorithm</a></li>\r\n</ul>\r\n\r\n<h3>News aus der Szene</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://docs.python.org/3/library/dataclasses.html">Data Classes</a></li>\r\n\t<li><a href="https://docs.python.org/3/library/collections.html#collections.namedtuple">Namedtuples</a></li>\r\n\t<li><a href="https://medium.com/hultner/try-out-walrus-operator-in-python-3-8-d030ce0ce601">Python 3.8 alpha - walrus operator</a></li>\r\n\t<li><a href="https://www.python.org/dev/peps/pep-0013/">Python steering council gew&auml;hlt</a></li>\r\n\t<li><a href="https://medium.com/@grassfedcode/goodbye-virtual-environments-b9f8115bc2b6">Python local packages</a></li>\r\n</ul>\r\n\r\n<h3>Quellen f&uuml;r News &uuml;ber Python</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://planetpython.org/">Planet Python</a></li>\r\n\t<li><a href="https://python.libhunt.com/newsletter">Awesome Python</a></li>\r\n\t<li><a href="https://importpython.com/newsletter/">Import Python</a></li>\r\n\t<li><a href="https://mailchi.mp/pythonweekly/python-weekly-issue-378?e=0122ee0efc">Python Weekly</a></li>\r\n\t<li><a href="https://github.com/trending/python?since=daily">Github: Trending Python Repositories</a>&nbsp;bzw&nbsp;<a href="https://github.com/trending/python?since=daily">Trending Repos Subscription</a></li>\r\n</ul>\r\n\r\n<h3>Picks</h3>\r\n\r\n<ul>\r\n\t<li><a href="https://docs.python.org/3/library/pathlib.html">Pathlib</a></li>\r\n\t<li><a href="https://github.com/andialbrecht/sqlparse">Sqlparse</a></li>\r\n\t<li><a href="http://omz-software.com/pythonista/">Pythonista</a></li>\r\n\t<li><a href="https://kivy.org/#home">Kivy</a></li>\r\n\t<li><a href="https://termux.com/">Termux</a></li>\r\n\t<li><a href="https://www.raspberrypi.org/documentation/usage/gpio/python/README.md">GPIO</a></li>\r\n\t<li><a href="https://docs.python.org/3/library/dis.html">Disassembler for Python bytecode</a></li>\r\n\t<li><a href="http://docs.python-requests.org/en/master/">Requests: HTTP for Humans</a></li>\r\n\t<li><a href="https://aiohttp.readthedocs.io/en/stable/">Asynchronous HTTP Client/Server for asyncio and Python</a></li>\r\n\t<li><a href="http://www.aosabook.org/en/500L/a-web-crawler-with-asyncio-coroutines.html">A Web Crawler With asyncio Coroutines</a></li>\r\n</ul>	python-fuer-einsteiger	4	1	8	c83f21b7-46ad-4f30-a234-327e977e4e56	python einsteiger chaosdorf	2	f
\.


--
-- Data for Name: cast_post_audios; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_post_audios (id, post_id, audio_id) FROM stdin;
1	2	5
2	3	6
3	4	7
4	5	8
6	7	9
\.


--
-- Data for Name: cast_post_galleries; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_post_galleries (id, post_id, gallery_id) FROM stdin;
\.


--
-- Data for Name: cast_post_images; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_post_images (id, post_id, image_id) FROM stdin;
\.


--
-- Data for Name: cast_post_videos; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_post_videos (id, post_id, video_id) FROM stdin;
\.


--
-- Data for Name: cast_video; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.cast_video (id, created, modified, original, poster, poster_seconds, user_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2018-11-21 09:18:45.839527+00	1	ItunesArtWork object (1)	1	[{"added": {}}]	21	4
2	2018-11-21 10:21:23.096508+00	5	Audio object (5)	1	[{"added": {}}]	20	4
3	2018-11-21 10:24:24.316668+00	5	Audio object (5)	2	[{"changed": {"fields": ["mp3"]}}]	20	4
4	2018-11-21 10:39:42.451069+00	5	Audio object (5)	2	[{"changed": {"fields": ["oga"]}}]	20	4
5	2018-11-21 10:43:02.008197+00	5	Audio object (5)	2	[{"changed": {"fields": ["opus"]}}]	20	4
6	2018-11-21 10:43:48.077641+00	5	Audio object (5)	2	[{"changed": {"fields": ["title", "subtitle"]}}]	20	4
7	2018-11-21 10:45:39.473213+00	1	Python Podcast	1	[{"added": {}}]	14	4
8	2018-11-21 10:50:49.424506+00	2	Die erste Sendung	2	[{"changed": {"fields": ["podcast_audio", "keywords", "explicit", "audios"]}}]	18	4
9	2018-11-21 13:01:19.594672+00	5	dominik	2	[{"changed": {"fields": ["is_superuser"]}}]	12	4
10	2018-11-21 13:06:16.274478+00	4	jochen	2	[{"changed": {"fields": ["first_name", "last_name"]}}]	12	4
11	2018-11-21 13:07:12.226425+00	5	dominik	2	[{"changed": {"fields": ["is_staff"]}}]	12	4
12	2018-11-21 13:08:46.402258+00	2	Die erste Sendung	2	[{"changed": {"fields": ["author", "keywords"]}}]	18	5
13	2018-11-21 13:10:55.137792+00	4	jochen	2	[{"changed": {"fields": ["name"]}}]	12	4
14	2018-11-21 13:11:03.320972+00	4	jochen	2	[{"changed": {"fields": ["name"]}}]	12	4
15	2018-11-21 13:19:55.519767+00	1	Python Podcast	2	[{"changed": {"fields": ["keywords"]}}]	14	4
16	2018-11-21 16:00:52.072701+00	1	Python Podcast	2	[{"changed": {"fields": ["itunes_categories"]}}]	14	4
17	2018-11-21 16:01:00.666751+00	1	Python Podcast	2	[{"changed": {"fields": ["keywords"]}}]	14	4
18	2018-11-28 10:18:49.964813+00	6	Audio object (6)	1	[{"added": {}}]	20	4
19	2018-11-28 10:19:31.695271+00	6	Audio object (6)	2	[{"changed": {"fields": ["m4a"]}}]	20	4
20	2018-11-28 10:20:40.561701+00	6	Audio object (6)	2	[{"changed": {"fields": ["mp3"]}}]	20	4
21	2018-11-28 10:21:39.305237+00	6	Audio object (6)	2	[{"changed": {"fields": ["oga"]}}]	20	4
22	2018-11-28 10:22:24.306578+00	6	Audio object (6)	2	[{"changed": {"fields": ["opus"]}}]	20	4
23	2018-11-28 10:23:25.655262+00	6	Audio object (6)	2	[{"changed": {"fields": ["title"]}}]	20	4
24	2018-11-28 10:24:03.299844+00	6	Audio object (6)	2	[{"changed": {"fields": ["subtitle"]}}]	20	4
25	2018-11-28 10:26:00.381809+00	3	PP02 - Django	2	[{"changed": {"fields": ["podcast_audio", "explicit"]}}]	18	4
26	2018-11-30 14:40:34.839657+00	1	ItunesArtWork object (1)	2	[{"changed": {"fields": ["original"]}}]	21	4
27	2018-12-01 20:30:47.854488+00	2	PP01 - Die erste Sendung	2	[{"changed": {"fields": ["visible_date", "content"]}}]	18	4
28	2018-12-18 09:20:58.185303+00	7	Audio object (7)	1	[{"added": {}}]	20	4
29	2018-12-18 09:22:46.360589+00	7	Audio object (7)	2	[{"changed": {"fields": ["title", "subtitle"]}}]	20	4
30	2018-12-18 09:24:31.093837+00	4	PP03 - Weihnachtsfolge	1	[{"added": {}}]	18	4
31	2019-02-20 11:19:10.400442+00	8	Audio object (8)	1	[{"added": {}}]	20	4
32	2019-02-20 11:23:34.309476+00	8	Audio object (8)	2	[{"changed": {"fields": ["title"]}}]	20	4
33	2019-02-20 11:23:46.265032+00	8	Audio object (8)	2	[{"changed": {"fields": ["title"]}}]	20	4
34	2019-02-20 12:13:29.103966+00	8	Audio object (8)	2	[{"changed": {"fields": ["m4a", "mp3", "oga", "opus"]}}]	20	4
35	2019-02-21 17:42:26.250157+00	5	PP04 - Python für Einsteiger	2	[{"changed": {"fields": ["podcast_audio", "keywords", "explicit"]}}]	18	4
36	2019-02-21 17:43:03.341376+00	8	Audio object (8)	2	[{"changed": {"fields": ["subtitle"]}}]	20	4
37	2019-02-23 10:21:38.645768+00	1	Python Podcast	2	[{"changed": {"fields": ["itunes_categories"]}}]	14	4
38	2019-02-25 11:27:25.312436+00	9	Audio object (9)	1	[{"added": {}}]	20	4
39	2019-02-25 11:32:54.413195+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["podcast_audio", "explicit", "content"]}}]	18	4
40	2019-02-25 11:33:37.565518+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content", "audios"]}}]	18	4
41	2019-02-25 11:35:02.679584+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["keywords"]}}]	18	4
42	2019-02-25 11:41:08.397991+00	10	Audio object (10)	1	[{"added": {}}]	20	4
43	2019-02-25 11:44:02.288111+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
44	2019-02-25 11:46:03.879888+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
45	2019-02-25 11:50:25.592625+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
46	2019-02-25 11:59:56.558743+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
47	2019-02-25 12:03:41.461099+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
48	2019-02-25 12:07:17.786603+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
49	2019-02-25 12:16:23.445475+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
50	2019-02-25 13:48:49.697488+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	4
51	2019-02-25 14:02:51.277844+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["content"]}}]	18	5
52	2019-02-25 14:09:51.012181+00	7	PP05 - Datenbanken	2	[{"changed": {"fields": ["pub_date", "visible_date"]}}]	18	5
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	users	user
13	authtoken	token
14	cast	blog
15	cast	file
16	cast	gallery
17	cast	image
18	cast	post
19	cast	video
20	cast	audio
21	cast	itunesartwork
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-11-08 15:56:42.140393+00
2	contenttypes	0002_remove_content_type_name	2018-11-08 15:56:42.156075+00
3	auth	0001_initial	2018-11-08 15:56:42.256831+00
4	auth	0002_alter_permission_name_max_length	2018-11-08 15:56:42.267049+00
5	auth	0003_alter_user_email_max_length	2018-11-08 15:56:42.277376+00
6	auth	0004_alter_user_username_opts	2018-11-08 15:56:42.288473+00
7	auth	0005_alter_user_last_login_null	2018-11-08 15:56:42.299655+00
8	auth	0006_require_contenttypes_0002	2018-11-08 15:56:42.302392+00
9	auth	0007_alter_validators_add_error_messages	2018-11-08 15:56:42.313419+00
10	auth	0008_alter_user_username_max_length	2018-11-08 15:56:42.326096+00
11	users	0001_initial	2018-11-08 15:56:42.441534+00
12	account	0001_initial	2018-11-08 15:56:42.534931+00
13	account	0002_email_max_length	2018-11-08 15:56:42.550584+00
14	admin	0001_initial	2018-11-08 15:56:42.60576+00
15	admin	0002_logentry_remove_auto_add	2018-11-08 15:56:42.621812+00
16	admin	0003_logentry_add_action_flag_choices	2018-11-08 15:56:42.638461+00
17	auth	0009_alter_user_last_name_max_length	2018-11-08 15:56:42.653588+00
18	sessions	0001_initial	2018-11-08 15:56:42.696077+00
19	sites	0001_initial	2018-11-08 15:56:42.713272+00
20	sites	0002_alter_domain_unique	2018-11-08 15:56:42.737964+00
21	sites	0003_set_site_domain_and_name	2018-11-08 15:56:42.761546+00
22	socialaccount	0001_initial	2018-11-08 15:56:42.924566+00
23	socialaccount	0002_token_max_lengths	2018-11-08 15:56:42.962846+00
24	socialaccount	0003_extra_data_default_dict	2018-11-08 15:56:42.978048+00
25	authtoken	0001_initial	2018-11-20 18:17:59.567336+00
26	authtoken	0002_auto_20160226_1747	2018-11-20 18:17:59.618218+00
27	cast	0001_initial	2018-11-20 18:18:00.07367+00
28	cast	0002_auto_20181109_0640	2018-11-20 18:18:00.230863+00
29	cast	0003_audio_duration	2018-11-20 18:18:00.256496+00
30	cast	0004_auto_20181109_0941	2018-11-20 18:18:00.279811+00
31	cast	0005_auto_20181109_1134	2018-11-20 18:18:00.337021+00
32	cast	0006_auto_20181109_1159	2018-11-20 18:18:00.382252+00
33	cast	0007_post_podcast	2018-11-20 18:18:00.415883+00
34	cast	0008_auto_20181119_1107	2018-11-20 18:18:00.61751+00
35	cast	0009_blog_uuid	2018-11-20 18:18:00.699862+00
36	cast	0010_blog_email	2018-11-20 18:18:00.725645+00
37	cast	0011_post_uuid	2018-11-20 18:18:00.81156+00
38	cast	0012_auto_20181119_1612	2018-11-20 18:18:00.903782+00
39	cast	0013_remove_blog_image	2018-11-20 18:18:00.935885+00
40	cast	0014_auto_20181119_1616	2018-11-20 18:18:00.949064+00
41	cast	0015_blog_keywords	2018-11-20 18:18:01.025596+00
42	cast	0016_post_keywords	2018-11-20 18:18:01.114371+00
43	cast	0017_auto_20181119_1707	2018-11-20 18:18:01.272993+00
44	cast	0018_post_block	2018-11-20 18:18:01.360758+00
45	cast	0019_auto_20181120_1024	2018-11-20 18:18:01.441877+00
46	cast	0020_auto_20181120_1034	2018-11-20 18:18:01.48249+00
47	cast	0020_auto_20181121_1446	2018-11-21 16:00:02.007638+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
9xe3qse4tqor5vff4xsrwlhexk782qss	MDYwY2U1NDM2N2YwZWNjNmYwNGQ0YzUyOTAxZTA4NzA2OWJkYjY3MDp7Il9zZXNzaW9uX2V4cGlyeSI6MH0=	2018-12-04 18:17:01.410833+00
zslqac3ht3x2t8q21cmaiycmpsgegxdg	OTVjZjI1ZTJkMzJmNWI5ZTFlZjBlNWI1OGI3Yjc1YWIyMDMwMTg2Yzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ODY0ODljNWYxMjM5YzdjMWQyYTg2N2ZhMWUzMmE2MWY0MGE4YmZiIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-04 18:17:16.309434+00
7rsgnapuaincoz652og6k79eog8u9x27	NTBkMDlhM2E3MzgxZGIxOThhMTI1MDQxMDYyMGMzZDBjZDg4MmU5NDp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MzNmZDRiOWViOGNhNGEyNzEyMzc5NDIyNzdjNzFkZDU5ODRiMTY3In0=	2018-12-05 13:07:17.906201+00
7l2kqcr7ivply11gjou4bk71wnvt7w6u	OTVjZjI1ZTJkMzJmNWI5ZTFlZjBlNWI1OGI3Yjc1YWIyMDMwMTg2Yzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ODY0ODljNWYxMjM5YzdjMWQyYTg2N2ZhMWUzMmE2MWY0MGE4YmZiIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-12 10:16:56.739078+00
sk9p17npoocm6zf5hwpt6j1pjvgr6g6g	MWEzZTZjOTkxMWU2M2ZjZDNiN2M1MDJhNTUzN2IxNjFhZjJjNzViOTp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MzNmZDRiOWViOGNhNGEyNzEyMzc5NDIyNzdjNzFkZDU5ODRiMTY3IiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-12 10:50:04.456113+00
a9mjcnpwf4jd08phi8i8ubk182qky29e	MWEzZTZjOTkxMWU2M2ZjZDNiN2M1MDJhNTUzN2IxNjFhZjJjNzViOTp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MzNmZDRiOWViOGNhNGEyNzEyMzc5NDIyNzdjNzFkZDU5ODRiMTY3IiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-12 10:51:55.197007+00
92v1hiyqtvev93a5n53wsms6zuhjvpt7	OTVjZjI1ZTJkMzJmNWI5ZTFlZjBlNWI1OGI3Yjc1YWIyMDMwMTg2Yzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ODY0ODljNWYxMjM5YzdjMWQyYTg2N2ZhMWUzMmE2MWY0MGE4YmZiIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-12 16:20:43.106256+00
ol2w0ytst70u2ps3kzouossb9pp73mne	MjA4MTgyZDVlMDI5NmRkN2RlNDM1MDY2NjA1NzI5ODY5ZDlhNDVlMzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-16 12:54:12.056341+00
cpyn990obp778dvfg288yz48awvrgtk0	M2M3NGM5MTBlZDExNjdmY2QxNDY5MzBmZjYxYzZiMWMwZWZiNDliNjp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIn0=	2018-12-17 10:50:47.47487+00
8izuxu5xbs6480nglz9ggmxtknbq8tpk	MjA4MTgyZDVlMDI5NmRkN2RlNDM1MDY2NjA1NzI5ODY5ZDlhNDVlMzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-01-01 09:18:52.391802+00
8w1jft1oidirg89q476wi9veo073tku2	YjRlNjZjOWVmNzcyYTU3Y2QxY2EwOWI4YjczNDQwMDI2NDI2OTE3NDp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyNmE2NDk3NGI2YWU3MzAwYWUxOTJiNmEwZGEwNjFlYWU0Y2RlZmYwIiwiX3Nlc3Npb25fZXhwaXJ5IjoxMjA5NjAwfQ==	2019-01-01 09:37:55.077871+00
m5lqvdrhat0myo02cxctffppxeob15pn	MjA4MTgyZDVlMDI5NmRkN2RlNDM1MDY2NjA1NzI5ODY5ZDlhNDVlMzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-01-03 09:20:54.538298+00
04x8nn09232ht1yuawbczzp2fmruk4mk	OTY4MTE1ZDNhZmRjNzg0N2VkMzg1NDY4MzMyOWMxZTU1MzgyZjg1YTp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyNmE2NDk3NGI2YWU3MzAwYWUxOTJiNmEwZGEwNjFlYWU0Y2RlZmYwIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-01-03 12:37:55.759036+00
57e16a64laz8vf4ayirpii1rvmw14dbc	MjA4MTgyZDVlMDI5NmRkN2RlNDM1MDY2NjA1NzI5ODY5ZDlhNDVlMzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-01-03 12:49:21.747271+00
8i06q47wcojmvfxj8b03knqv36gf2n8q	OTY4MTE1ZDNhZmRjNzg0N2VkMzg1NDY4MzMyOWMxZTU1MzgyZjg1YTp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyNmE2NDk3NGI2YWU3MzAwYWUxOTJiNmEwZGEwNjFlYWU0Y2RlZmYwIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-03-06 11:27:10.576279+00
n34q86argpi75ecytvxnr8n2t5tydnbt	MjA4MTgyZDVlMDI5NmRkN2RlNDM1MDY2NjA1NzI5ODY5ZDlhNDVlMzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTQzZDE0Y2IxZDU3MTg4OGFlYjY5NjhhZjAwNjAxYTM2NjRmMzVjIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-03-07 17:41:26.265485+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.django_site (id, domain, name) FROM stdin;
1	python-podcast.de	Python Podcast
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
5	argon2$argon2i$v=19$m=512,t=2,p=2$R1JZa0Fwc29vWVlx$NpBjD0sIB4A9BJjyyxaaDQ	2019-02-20 11:27:10.532837+00	t	dominik			podcast@soila.de	t	t	2018-11-21 12:56:41+00	Dominik
4	argon2$argon2i$v=19$m=512,t=2,p=2$MElUT2tWTmI2SVJa$5leZQEsMzGtfymGzpe7o4Q	2019-02-21 17:41:26.224594+00	t	jochen	Jochen	Wersdörfer	jochen-pythonpodcast@wersdoerfer.de	t	t	2018-11-20 17:58:57+00	Jochen
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 6, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 84, true);


--
-- Name: cast_audio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_audio_id_seq', 10, true);


--
-- Name: cast_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_blog_id_seq', 1, true);


--
-- Name: cast_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_file_id_seq', 1, false);


--
-- Name: cast_gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_gallery_id_seq', 1, false);


--
-- Name: cast_gallery_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_gallery_images_id_seq', 1, false);


--
-- Name: cast_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_image_id_seq', 1, false);


--
-- Name: cast_itunesartwork_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_itunesartwork_id_seq', 1, true);


--
-- Name: cast_post_audios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_post_audios_id_seq', 6, true);


--
-- Name: cast_post_galleries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_post_galleries_id_seq', 1, false);


--
-- Name: cast_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_post_id_seq', 7, true);


--
-- Name: cast_post_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_post_images_id_seq', 1, false);


--
-- Name: cast_post_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_post_videos_id_seq', 1, false);


--
-- Name: cast_video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.cast_video_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 52, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 21, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 47, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.users_user_id_seq', 5, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: cast_audio cast_audio_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_audio
    ADD CONSTRAINT cast_audio_pkey PRIMARY KEY (id);


--
-- Name: cast_blog cast_blog_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_blog
    ADD CONSTRAINT cast_blog_pkey PRIMARY KEY (id);


--
-- Name: cast_file cast_file_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_file
    ADD CONSTRAINT cast_file_pkey PRIMARY KEY (id);


--
-- Name: cast_gallery_images cast_gallery_images_gallery_id_image_id_0d5a4117_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery_images
    ADD CONSTRAINT cast_gallery_images_gallery_id_image_id_0d5a4117_uniq UNIQUE (gallery_id, image_id);


--
-- Name: cast_gallery_images cast_gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery_images
    ADD CONSTRAINT cast_gallery_images_pkey PRIMARY KEY (id);


--
-- Name: cast_gallery cast_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery
    ADD CONSTRAINT cast_gallery_pkey PRIMARY KEY (id);


--
-- Name: cast_image cast_image_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_image
    ADD CONSTRAINT cast_image_pkey PRIMARY KEY (id);


--
-- Name: cast_itunesartwork cast_itunesartwork_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_itunesartwork
    ADD CONSTRAINT cast_itunesartwork_pkey PRIMARY KEY (id);


--
-- Name: cast_post_audios cast_post_audios_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_audios
    ADD CONSTRAINT cast_post_audios_pkey PRIMARY KEY (id);


--
-- Name: cast_post_audios cast_post_audios_post_id_audio_id_6b2051a8_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_audios
    ADD CONSTRAINT cast_post_audios_post_id_audio_id_6b2051a8_uniq UNIQUE (post_id, audio_id);


--
-- Name: cast_post_galleries cast_post_galleries_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_galleries
    ADD CONSTRAINT cast_post_galleries_pkey PRIMARY KEY (id);


--
-- Name: cast_post_galleries cast_post_galleries_post_id_gallery_id_e6f381b9_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_galleries
    ADD CONSTRAINT cast_post_galleries_post_id_gallery_id_e6f381b9_uniq UNIQUE (post_id, gallery_id);


--
-- Name: cast_post_images cast_post_images_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_images
    ADD CONSTRAINT cast_post_images_pkey PRIMARY KEY (id);


--
-- Name: cast_post_images cast_post_images_post_id_image_id_eccbcb19_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_images
    ADD CONSTRAINT cast_post_images_post_id_image_id_eccbcb19_uniq UNIQUE (post_id, image_id);


--
-- Name: cast_post cast_post_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post
    ADD CONSTRAINT cast_post_pkey PRIMARY KEY (id);


--
-- Name: cast_post_videos cast_post_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_videos
    ADD CONSTRAINT cast_post_videos_pkey PRIMARY KEY (id);


--
-- Name: cast_post_videos cast_post_videos_post_id_video_id_714c18ae_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_videos
    ADD CONSTRAINT cast_post_videos_post_id_video_id_714c18ae_uniq UNIQUE (post_id, video_id);


--
-- Name: cast_video cast_video_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_video
    ADD CONSTRAINT cast_video_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: cast_audio_user_id_6f77ecf5; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_audio_user_id_6f77ecf5 ON public.cast_audio USING btree (user_id);


--
-- Name: cast_blog_itunes_artwork_id_4e08d656; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_blog_itunes_artwork_id_4e08d656 ON public.cast_blog USING btree (itunes_artwork_id);


--
-- Name: cast_blog_slug_271fed17; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_blog_slug_271fed17 ON public.cast_blog USING btree (slug);


--
-- Name: cast_blog_slug_271fed17_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_blog_slug_271fed17_like ON public.cast_blog USING btree (slug varchar_pattern_ops);


--
-- Name: cast_blog_user_id_84349a78; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_blog_user_id_84349a78 ON public.cast_blog USING btree (user_id);


--
-- Name: cast_file_user_id_e84e677c; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_file_user_id_e84e677c ON public.cast_file USING btree (user_id);


--
-- Name: cast_gallery_images_gallery_id_88a10d79; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_gallery_images_gallery_id_88a10d79 ON public.cast_gallery_images USING btree (gallery_id);


--
-- Name: cast_gallery_images_image_id_b8897293; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_gallery_images_image_id_b8897293 ON public.cast_gallery_images USING btree (image_id);


--
-- Name: cast_gallery_user_id_136d6ba5; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_gallery_user_id_136d6ba5 ON public.cast_gallery USING btree (user_id);


--
-- Name: cast_image_user_id_886b3a11; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_image_user_id_886b3a11 ON public.cast_image USING btree (user_id);


--
-- Name: cast_post_audios_audio_id_71864e9f; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_audios_audio_id_71864e9f ON public.cast_post_audios USING btree (audio_id);


--
-- Name: cast_post_audios_post_id_0baaf876; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_audios_post_id_0baaf876 ON public.cast_post_audios USING btree (post_id);


--
-- Name: cast_post_author_id_047885e5; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_author_id_047885e5 ON public.cast_post USING btree (author_id);


--
-- Name: cast_post_blog_id_6108521b; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_blog_id_6108521b ON public.cast_post USING btree (blog_id);


--
-- Name: cast_post_galleries_gallery_id_673f4ed3; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_galleries_gallery_id_673f4ed3 ON public.cast_post_galleries USING btree (gallery_id);


--
-- Name: cast_post_galleries_post_id_3b2c96b8; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_galleries_post_id_3b2c96b8 ON public.cast_post_galleries USING btree (post_id);


--
-- Name: cast_post_images_image_id_445a44f3; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_images_image_id_445a44f3 ON public.cast_post_images USING btree (image_id);


--
-- Name: cast_post_images_post_id_8560067f; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_images_post_id_8560067f ON public.cast_post_images USING btree (post_id);


--
-- Name: cast_post_podcast_id_030e68d0; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_podcast_id_030e68d0 ON public.cast_post USING btree (podcast_audio_id);


--
-- Name: cast_post_slug_58c05222; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_slug_58c05222 ON public.cast_post USING btree (slug);


--
-- Name: cast_post_slug_58c05222_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_slug_58c05222_like ON public.cast_post USING btree (slug varchar_pattern_ops);


--
-- Name: cast_post_videos_post_id_89cd3c57; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_videos_post_id_89cd3c57 ON public.cast_post_videos USING btree (post_id);


--
-- Name: cast_post_videos_video_id_24fccc3d; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_post_videos_video_id_24fccc3d ON public.cast_post_videos USING btree (video_id);


--
-- Name: cast_video_user_id_89fcd953; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX cast_video_user_id_89fcd953 ON public.cast_video USING btree (user_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_audio cast_audio_user_id_6f77ecf5_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_audio
    ADD CONSTRAINT cast_audio_user_id_6f77ecf5_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_blog cast_blog_itunes_artwork_id_4e08d656_fk_cast_itunesartwork_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_blog
    ADD CONSTRAINT cast_blog_itunes_artwork_id_4e08d656_fk_cast_itunesartwork_id FOREIGN KEY (itunes_artwork_id) REFERENCES public.cast_itunesartwork(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_blog cast_blog_user_id_84349a78_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_blog
    ADD CONSTRAINT cast_blog_user_id_84349a78_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_file cast_file_user_id_e84e677c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_file
    ADD CONSTRAINT cast_file_user_id_e84e677c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_gallery_images cast_gallery_images_gallery_id_88a10d79_fk_cast_gallery_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery_images
    ADD CONSTRAINT cast_gallery_images_gallery_id_88a10d79_fk_cast_gallery_id FOREIGN KEY (gallery_id) REFERENCES public.cast_gallery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_gallery_images cast_gallery_images_image_id_b8897293_fk_cast_image_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery_images
    ADD CONSTRAINT cast_gallery_images_image_id_b8897293_fk_cast_image_id FOREIGN KEY (image_id) REFERENCES public.cast_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_gallery cast_gallery_user_id_136d6ba5_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_gallery
    ADD CONSTRAINT cast_gallery_user_id_136d6ba5_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_image cast_image_user_id_886b3a11_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_image
    ADD CONSTRAINT cast_image_user_id_886b3a11_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_audios cast_post_audios_audio_id_71864e9f_fk_cast_audio_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_audios
    ADD CONSTRAINT cast_post_audios_audio_id_71864e9f_fk_cast_audio_id FOREIGN KEY (audio_id) REFERENCES public.cast_audio(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_audios cast_post_audios_post_id_0baaf876_fk_cast_post_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_audios
    ADD CONSTRAINT cast_post_audios_post_id_0baaf876_fk_cast_post_id FOREIGN KEY (post_id) REFERENCES public.cast_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post cast_post_author_id_047885e5_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post
    ADD CONSTRAINT cast_post_author_id_047885e5_fk_users_user_id FOREIGN KEY (author_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post cast_post_blog_id_6108521b_fk_cast_blog_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post
    ADD CONSTRAINT cast_post_blog_id_6108521b_fk_cast_blog_id FOREIGN KEY (blog_id) REFERENCES public.cast_blog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_galleries cast_post_galleries_gallery_id_673f4ed3_fk_cast_gallery_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_galleries
    ADD CONSTRAINT cast_post_galleries_gallery_id_673f4ed3_fk_cast_gallery_id FOREIGN KEY (gallery_id) REFERENCES public.cast_gallery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_galleries cast_post_galleries_post_id_3b2c96b8_fk_cast_post_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_galleries
    ADD CONSTRAINT cast_post_galleries_post_id_3b2c96b8_fk_cast_post_id FOREIGN KEY (post_id) REFERENCES public.cast_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_images cast_post_images_image_id_445a44f3_fk_cast_image_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_images
    ADD CONSTRAINT cast_post_images_image_id_445a44f3_fk_cast_image_id FOREIGN KEY (image_id) REFERENCES public.cast_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_images cast_post_images_post_id_8560067f_fk_cast_post_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_images
    ADD CONSTRAINT cast_post_images_post_id_8560067f_fk_cast_post_id FOREIGN KEY (post_id) REFERENCES public.cast_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post cast_post_podcast_audio_id_b0d58576_fk_cast_audio_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post
    ADD CONSTRAINT cast_post_podcast_audio_id_b0d58576_fk_cast_audio_id FOREIGN KEY (podcast_audio_id) REFERENCES public.cast_audio(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_videos cast_post_videos_post_id_89cd3c57_fk_cast_post_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_videos
    ADD CONSTRAINT cast_post_videos_post_id_89cd3c57_fk_cast_post_id FOREIGN KEY (post_id) REFERENCES public.cast_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_post_videos cast_post_videos_video_id_24fccc3d_fk_cast_video_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_post_videos
    ADD CONSTRAINT cast_post_videos_video_id_24fccc3d_fk_cast_video_id FOREIGN KEY (video_id) REFERENCES public.cast_video(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cast_video cast_video_user_id_89fcd953_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.cast_video
    ADD CONSTRAINT cast_video_user_id_89fcd953_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: ayVYOYUiXAuVwlpjXkeOQcyWoWKqRzyc
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

